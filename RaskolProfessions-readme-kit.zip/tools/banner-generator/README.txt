Генератор баннеров (Python 3, без зависимостей).
  python3 banner.py ../../assets          -> banner.svg (день) + banner-dark.svg (ночь)
  python3 icons.py  ../../assets/icons    -> иконки профессий (+ divider.svg: перенесите в assets/)
Меняйте палитру/спрайты в banner.py и перегенерируйте.
