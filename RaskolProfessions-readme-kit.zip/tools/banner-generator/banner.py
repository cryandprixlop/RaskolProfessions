import math, sys
from engine import *

W, H = 1280, 540
G = 100                     # строка сетки, где начинается земля (y = 440)
GY = G * P
PITCH = 205
CX = [120 + PITCH * k for k in range(6)]   # центры станций
OX = [c - 50 for c in CX]                    # левый край спрайта 20×27 клеток
OY = GY - 27 * P

SKIN, SKIN2, EYE, BLUSH = '#f2c49b', '#d9a27a', '#2b1d1a', '#e8907c'
WOOD, WOOD_D, WOOD_L = '#8a5a2b', '#5b3a1a', '#b27a3d'
STEEL, STEEL_D, STEEL_L = '#9aa3ad', '#6b727c', '#d3dae1'
EM_Y, EM_O, EM_C, EM_V = '*#ffd24a', '*#ff9a2e', '*#8ff3ff', '*#c9a8ff'

# ================= ПЕРСОНАЖИ =================
def person(hair, tunic, tunic2, pants, boots, belt=None):
    pants2 = mix(pants, '#000000', 0.18)
    legs, up = {}, {}
    rect(legs, 6, 22, 9, 24, pants); rect(legs, 10, 22, 13, 24, pants2)
    rect(legs, 6, 25, 9, 26, boots); rect(legs, 10, 25, 13, 26, mix(boots, '#000000', 0.15))
    rect(up, 6, 15, 13, 21, tunic)
    rect(up, 4, 15, 5, 20, tunic2); rect(up, 14, 15, 15, 20, tunic2)
    rect(up, 4, 21, 5, 21, SKIN); rect(up, 14, 21, 15, 21, SKIN)
    if belt: rect(up, 6, 19, 13, 19, belt)
    rect(up, 6, 8, 13, 14, SKIN)
    rect(up, 6, 7, 13, 8, hair); up[(6, 9)] = up[(13, 9)] = hair
    up[(8, 11)] = up[(11, 11)] = EYE
    up[(7, 12)] = up[(12, 12)] = BLUSH
    return legs, up

def tool_pick():
    d = {}
    rect(d, 16, 10, 16, 24, WOOD)
    for y in range(10, 25, 3): d[(16, y)] = WOOD_L
    rect(d, 14, 9, 18, 9, STEEL); rect(d, 15, 8, 17, 8, STEEL_L)
    d[(14, 10)] = d[(18, 10)] = STEEL_D; d[(14, 9)] = d[(18, 9)] = STEEL_D
    return d

def tool_axe():
    d = {}
    rect(d, 16, 10, 16, 24, WOOD)
    for y in range(11, 25, 3): d[(16, y)] = WOOD_L
    rect(d, 17, 9, 18, 9, STEEL); rect(d, 17, 10, 19, 12, STEEL); rect(d, 17, 13, 18, 13, STEEL)
    rect(d, 19, 10, 19, 12, STEEL_L); d[(17, 12)] = d[(17, 13)] = STEEL_D
    return d

def tool_fork():
    d = {}
    rect(d, 16, 9, 16, 24, WOOD)
    rect(d, 14, 8, 18, 8, STEEL_D)
    for x in (14, 16, 18): rect(d, x, 4, x, 7, STEEL)
    for x in (14, 16, 18): d[(x, 4)] = STEEL_L
    return d

def tool_rod():
    d = {}
    for (x, y) in [(16, 21), (17, 20), (18, 19), (19, 18), (20, 17), (21, 16), (22, 15), (23, 14), (24, 13), (25, 12)]:
        d[(x, y)] = WOOD
    d[(25, 12)] = WOOD_L; d[(16, 21)] = WOOD_D
    return d

def tool_hammer():
    d = {}
    rect(d, 16, 12, 16, 24, WOOD)
    for y in range(13, 25, 3): d[(16, y)] = WOOD_L
    rect(d, 14, 9, 18, 11, STEEL_D); rect(d, 14, 9, 18, 9, STEEL_L); d[(14, 10)] = STEEL
    return d

def tool_staff():
    d = {}
    rect(d, 16, 8, 16, 25, '#7a4f2a')
    for y in range(9, 26, 3): d[(16, y)] = WOOD_L
    d[(15, 8)] = d[(17, 8)] = '#e9c46a'; d[(16, 8)] = '#e9c46a'
    rect(d, 15, 5, 17, 7, EM_C); d[(16, 6)] = '*#ffffff'
    return d

def build_miner():
    legs, up = person('#5a3a22', '#8a5a3a', '#6e4429', '#4b5266', '#2f2523', '#4a2f1b')
    for y in range(15, 19): up[(7, y)] = up[(12, y)] = '#5b3a1f'
    rect(up, 9, 19, 10, 19, '#f2c94c')
    rect(up, 8, 5, 11, 5, '#9aa3ad'); rect(up, 7, 6, 12, 6, '#9aa3ad'); rect(up, 6, 7, 13, 7, '#aeb6c0')
    rect(up, 6, 8, 13, 8, '#6b727c'); rect(up, 8, 5, 11, 5, '#c3cad2')
    rect(up, 9, 6, 10, 7, EM_Y)
    return legs, merge(up, tool_pick())

def build_lumber():
    legs, up = person('#b0552a', '#c23b32', '#a83029', '#3f5a8c', '#3a2a22', '#2b1b14')
    for y in range(15, 21):
        for x in range(6, 14):
            if x % 3 == 0 or y % 3 == 0: up[(x, y)] = '#8f2323'
    for y in range(15, 21):
        for x in (4, 5, 14, 15):
            if (x + y) % 3 == 0: up[(x, y)] = '#8f2323'
    rect(up, 6, 13, 13, 16, '#b0552a'); rect(up, 7, 12, 12, 12, '#b0552a')
    up[(8, 14)] = up[(11, 14)] = '#c9703a'
    rect(up, 8, 5, 11, 5, '#2e7d5b'); rect(up, 7, 6, 12, 6, '#2e7d5b'); rect(up, 6, 7, 13, 7, '#2e7d5b')
    rect(up, 6, 8, 13, 8, '#1f5a41'); rect(up, 9, 4, 10, 4, '#d9d2a8')
    return legs, merge(up, tool_axe())

def build_farmer():
    legs, up = person('#7a4a24', '#f4efe0', '#e4dcc4', '#3d6bb3', '#4a3326')
    rect(up, 7, 17, 12, 21, '#3d6bb3'); rect(up, 7, 15, 7, 16, '#3d6bb3'); rect(up, 12, 15, 12, 16, '#3d6bb3')
    rect(up, 9, 19, 10, 20, '#2f548f'); up[(7, 17)] = up[(12, 17)] = '#e9c46a'
    rect(up, 7, 4, 12, 6, '#e8c45a'); rect(up, 7, 6, 12, 6, '#b9382e'); rect(up, 3, 7, 16, 7, '#d9ae42')
    up[(3, 8)] = up[(16, 8)] = '#b8902f'; rect(up, 8, 4, 10, 4, '#f3dc8a')
    return legs, merge(up, tool_fork())

def build_fisher():
    legs, up = person('#3a2a1a', '#2f9bb7', '#237a91', '#6b5a3c', '#3a2a22', '#1f6277')
    rect(up, 7, 5, 12, 7, '#f2c230'); rect(up, 7, 7, 12, 7, '#b88a12'); rect(up, 5, 8, 14, 8, '#e0ad1f')
    rect(up, 8, 5, 10, 5, '#ffe27a'); rect(up, 8, 16, 11, 17, '#e8f4f8')
    return legs, merge(up, tool_rod())

def build_smith():
    legs, up = person('#262626', '#4a4a55', '#3c3c46', '#3b3b46', '#2a1f1a')
    rect(up, 4, 18, 5, 20, SKIN2); rect(up, 14, 18, 15, 20, SKIN2)   # закатанные рукава
    rect(up, 7, 16, 12, 22, '#7a4a28'); rect(up, 7, 15, 7, 15, '#5b3a1f'); rect(up, 12, 15, 12, 15, '#5b3a1f')
    rect(up, 8, 18, 11, 18, '#5b3a1f'); rect(up, 6, 8, 13, 8, '#b8352b'); up[(7, 13)] = '#8a6a50'
    return legs, merge(up, tool_hammer())

def build_enchanter():
    up = {}
    rect(up, 6, 15, 13, 21, '#6a3fb5'); rect(up, 5, 22, 14, 26, '#6a3fb5')
    for y in range(15, 27):
        up[(6, y) if y < 22 else (5, y)] = '#583099'; up[(13, y) if y < 22 else (14, y)] = '#583099'
    rect(up, 5, 26, 14, 26, '#e9c46a'); rect(up, 6, 19, 13, 19, '#e9c46a'); rect(up, 9, 15, 10, 21, '#8a5fd6')
    rect(up, 4, 15, 5, 20, '#583099'); rect(up, 14, 15, 15, 20, '#583099')
    rect(up, 4, 21, 5, 21, SKIN); rect(up, 14, 21, 15, 21, SKIN)
    rect(up, 6, 8, 13, 14, SKIN); rect(up, 6, 8, 13, 8, '#dcdcdc'); up[(6, 9)] = up[(13, 9)] = '#dcdcdc'
    up[(8, 11)] = up[(11, 11)] = EYE; up[(7, 12)] = up[(12, 12)] = BLUSH
    rect(up, 7, 13, 12, 14, '#eeeeee'); rect(up, 8, 15, 11, 18, '#eeeeee'); rect(up, 9, 19, 10, 19, '#eeeeee')
    for (y, x0, x1) in [(0, 10, 10), (1, 9, 10), (2, 8, 11), (3, 8, 11), (4, 7, 12), (5, 7, 12), (6, 4, 15), (7, 4, 15)]:
        rect(up, x0, y, x1, y, '#5b32a3' if y < 6 else '#483082')
    rect(up, 7, 5, 12, 5, '#e9c46a'); up[(9, 3)] = '*#ffe9a0'; rect(up, 4, 7, 15, 7, '#3d2570')
    return {}, merge(up, tool_staff())

# ================= ПРЕДМЕТЫ =================
def minecart():
    d = {}
    rect(d, 0, 2, 11, 2, '#aeb4bd'); rect(d, 0, 3, 11, 5, '#8d939c'); rect(d, 0, 5, 11, 5, '#767c85')
    for x in (2, 5, 9): d[(x, 4)] = '#6d737c'
    rect(d, 2, 6, 3, 7, '#33363c'); rect(d, 8, 6, 9, 7, '#33363c'); rect(d, 0, 8, 11, 8, '#6f4a2a')
    rect(d, 1, 1, 10, 1, '#5f5f5f'); rect(d, 2, 0, 9, 0, '#6a6a6a')
    for (x, y, c) in [(3, 0, '#4fe3d6'), (4, 1, '#4fe3d6'), (6, 0, '#f2c94c'), (8, 0, '#f2c94c'), (7, 1, '#2b2b2b'), (2, 1, '#e8a77a'), (5, 0, '#2b2b2b')]:
        d[(x, y)] = c
    return d

def orebox():
    d = {}
    rect(d, 3, 2, 8, 7, '#8f8f8f'); rect(d, 3, 7, 8, 7, '#6d6d6d'); rect(d, 8, 2, 8, 7, '#767676')
    for (x, y) in [(4, 3), (5, 3), (4, 4), (6, 5), (7, 5), (6, 6), (3, 6)]: d[(x, y)] = '#4fe3d6'
    d[(5, 4)] = '#c8fff9'; d[(7, 6)] = '#c8fff9'
    rect(d, 0, 2, 0, 7, '#7a4f2a')
    return d

def torch_flame():
    d = {}
    rect(d, 0, 0, 0, 1, EM_O); d[(0, 0)] = '*#ffe066'
    return d

def tree():
    d = {}
    for (y, x0, x1) in [(0, 3, 8), (1, 1, 10), (2, 0, 11), (3, 0, 11), (4, 0, 11), (5, 0, 11), (6, 1, 10), (7, 3, 8)]:
        rect(d, x0, y, x1, y, '#4f9d3c')
    for (x, y) in [(2, 1), (6, 0), (9, 2), (4, 3), (1, 4), (7, 5), (10, 4), (5, 6), (3, 2)]: d[(x, y)] = '#6cbf4e'
    for (x, y) in [(3, 5), (8, 3), (6, 4), (2, 6), (9, 6), (5, 7), (7, 2)]: d[(x, y)] = '#3a7f2d'
    rect(d, 4, 8, 6, 14, WOOD); rect(d, 4, 8, 4, 14, WOOD_L); rect(d, 6, 8, 6, 14, WOOD_D)
    return d

def logpile():
    d = {}
    def log(x, y):
        rect(d, x, y, x + 3, y + 3, '#6b4423'); rect(d, x + 1, y + 1, x + 2, y + 2, '#d9a45d'); d[(x + 1, y + 1)] = '#f0c27a'
    log(0, 4); log(4, 4); log(2, 0)
    return d

def wheat():
    d = {}
    rect(d, 0, 8, 11, 8, '#6b4a2b')
    hs = [6, 7, 5, 7, 6, 7, 5, 6, 7, 6, 5, 7]
    for x, h in enumerate(hs):
        rect(d, x, 8 - h, x, 7, '#b8a23a'); rect(d, x, 8 - h, x, 9 - h, '#e6c84a'); d[(x, 8 - h)] = '#f6dc6a'
    return d

def pumpkin_hay():
    d = {}
    rect(d, 0, 2, 5, 6, '#e8831c'); rect(d, 0, 6, 5, 6, '#c76a12')
    for x in (1, 4): rect(d, x, 2, x, 6, '#c76a12')
    rect(d, 2, 0, 3, 1, '#5c8f2e')
    rect(d, 6, 3, 11, 6, '#e3bf4f'); rect(d, 6, 3, 11, 3, '#f1d478'); rect(d, 6, 6, 11, 6, '#b8902f')
    for x in (8, 10): rect(d, x, 3, x, 6, '#7a4f2a')
    return d

def crate_barrel():
    d = {}
    rect(d, 0, 2, 4, 7, '#8a5a2b'); rect(d, 0, 3, 4, 3, '#5b3a1a'); rect(d, 0, 6, 4, 6, '#5b3a1a'); rect(d, 0, 2, 0, 7, '#6e4429'); rect(d, 4, 2, 4, 7, '#6e4429')
    rect(d, 1, 1, 3, 1, '#6e4429')
    rect(d, 6, 3, 11, 7, '#c08a4a'); rect(d, 6, 3, 11, 3, '#d9a45d')
    for k in range(0, 6): d[(6 + k, 3 + (k % 5))] = '#8a5a2b'
    rect(d, 7, 1, 10, 2, '#e8f4f8'); d[(7, 1)] = '#46c6e6'; d[(10, 2)] = '#46c6e6'; d[(8, 1)] = '#ffffff'
    return d

def forge():
    d = {}
    rect(d, 0, 1, 9, 9, '#8a8a8a')
    for y in range(1, 10):
        for x in range(0, 10):
            if (x + y * 2) % 5 == 0: d[(x, y)] = '#6e6e6e'
            if (x * 3 + y) % 7 == 0: d[(x, y)] = '#a0a0a0'
    rect(d, 6, 0, 8, 0, '#6e6e6e'); rect(d, 7, -3, 8, -1, '#6e6e6e')
    rect(d, 2, 4, 7, 8, '#2a1f1a')
    return d

def forge_fire():
    d = {}
    rect(d, 3, 6, 6, 8, '*#ff7a1a'); rect(d, 4, 5, 5, 8, '*#ffb02e'); rect(d, 4, 7, 5, 8, '*#ffe066')
    d[(3, 5)] = '*#ff7a1a'; d[(6, 5)] = '*#ff7a1a'
    return d

def anvil():
    d = {}
    rect(d, 0, 0, 6, 1, '#4a4d55'); rect(d, 0, 0, 6, 0, '#6a6e78'); rect(d, 7, 0, 8, 0, '#4a4d55')
    rect(d, 2, 2, 4, 3, '#3a3d45'); rect(d, 1, 4, 5, 4, '#4a4d55')
    rect(d, 0, 5, 6, 7, '#8a5a2b'); rect(d, 0, 5, 6, 5, '#c08a4a'); rect(d, 0, 5, 0, 7, '#6e4429')
    return d

def bookshelf():
    d = {}
    rect(d, 0, 0, 6, 9, '#7a4f2a'); rect(d, 0, 0, 6, 0, '#a56b34'); rect(d, 0, 4, 6, 5, '#5b3a1a'); rect(d, 0, 9, 6, 9, '#5b3a1a')
    cols = ['#b8352b', '#3f7fd0', '#4aa84a', '#8a5fd6', '#e8c45a', '#c9703a']
    for i in range(5):
        rect(d, 1 + i, 1, 1 + i, 3, cols[i % 6]); rect(d, 1 + ((i + 2) % 5), 6, 1 + ((i + 2) % 5), 8, cols[(i + 3) % 6])
    return d

def ench_table():
    d = {}
    rect(d, 1, 4, 10, 8, '#241a3f'); rect(d, 0, 2, 11, 3, '#241a3f'); rect(d, 0, 4, 0, 8, '#241a3f')
    rect(d, 1, 2, 10, 2, '#b02a35'); rect(d, 1, 3, 10, 3, '#8f1f2a')
    for (x, y) in [(2, 5), (4, 6), (7, 5), (9, 7), (5, 8)]: d[(x, y)] = '#3a2a66'
    d[(1, 4)] = d[(10, 4)] = '#4fe3d6'; d[(0, 2)] = '#4fe3d6'; d[(11, 2)] = '#4fe3d6'
    rect(d, 0, 8, 11, 8, '#1a1230')
    return d

def book():
    d = {}
    rect(d, 0, 1, 4, 2, '#f1e6c0'); rect(d, 6, 1, 10, 2, '#f1e6c0'); rect(d, 5, 0, 5, 2, '#b02a35')
    rect(d, 0, 3, 10, 3, '#7a1f2a')
    d[(1, 1)] = d[(3, 1)] = '#8a6a50'; d[(7, 1)] = d[(9, 1)] = '#8a6a50'
    rect(d, -1, -1, 0, 0, EM_V); rect(d, 10, -1, 11, 0, EM_C)
    return d

RUNES = [
    ['#.#', '.#.', '###', '.#.', '#.#'],
    ['.#.', '###', '.#.', '#.#', '.#.'],
    ['##.', '.##', '#..', '.##', '##.'],
]

def rune(i, col):
    return {(x, y): col for y, r in enumerate(RUNES[i % 3]) for x, ch in enumerate(r) if ch == '#'}

def on_ground(d, bottom_row=None):
    ys = [k[1] for k in d]
    return shift(d, 0, (bottom_row if bottom_row is not None else G - 1) - max(ys))

# ================= СЦЕНА =================
def ridge(seed, base, amp, n=256):
    ph = [hsh(seed, i) * 6.28 for i in range(4)]
    out = []
    for x in range(n):
        v = 0.55 * math.sin(x * 0.030 + ph[0]) + 0.30 * math.sin(x * 0.081 + ph[1]) + 0.15 * math.sin(x * 0.19 + ph[2])
        out.append(int(round(base - amp * (v * 0.5 + 0.5))))
    return out

def layer(tops, bottom, col, th, hi=None, dither=None, snow=None, seed=1):
    d = {}
    for x, t in enumerate(tops):
        for y in range(t, bottom):
            d[(x, y)] = col
        if hi: d[(x, t)] = hi
        if dither:
            for y in range(t + 2, bottom):
                if hsh(x, y, seed) < 0.07: d[(x, y)] = dither
        if snow and t < snow:
            for y in range(t, min(bottom, t + 3 - (x % 2))):
                d[(x, y)] = '#f4f8ff'
    return d

def pine(h=9):
    d = {}
    for i in range(h - 2):
        w = 1 + (i // 2) * 1
        rect(d, 3 - w, i, 3 + w, i, '#2f7a45' if (i % 2) else '#3b8f52')
    rect(d, 3, h - 2, 3, h - 1, WOOD_D)
    return d

def cottage(big=False):
    d = {}
    w = 18 if big else 14
    hh = 9 if big else 7
    rect(d, 1, 6, w - 2, 6 + hh, '#c9a46a'); rect(d, 1, 6, w - 2, 6, '#b88f55')
    for y in range(6, 6 + hh, 2): rect(d, 1, y, w - 2, y, '#b88f55')
    for i in range(7):
        rect(d, 0 + i, 6 - i, w - 1 - i, 6 - i, '#b8433a' if i % 2 == 0 else '#a23a32')
    rect(d, 0, 6, w - 1, 6, '#8e2f29')
    dx = w // 2 - 1
    rect(d, dx, 6 + hh - 4, dx + 1, 6 + hh, '#5b3a1a')
    rect(d, 2, 8, 3, 9, '*#ffd988'); rect(d, w - 4, 8, w - 3, 9, '*#ffd988')
    rect(d, w - 5 if not big else w - 6, -2, w - 4 if not big else w - 5, 3, '#8a8a8a')
    return d

def sprite_group(d, x, y, th, extra='', s=P):
    return render(outlined(d), x, y, s, th, extra)

def build(theme):
    th = Theme(theme)
    N = th.night
    o = []
    # ---------- defs ----------
    sky = ('#0f0c2e', '#2a2266', '#6a3f8c', '#d5707a') if N else ('#68bff4', '#a9def9', '#d9f0f8', '#ffe8b4')
    o.append('<defs><linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">'
             '<stop offset="0" stop-color="%s"/><stop offset=".45" stop-color="%s"/><stop offset=".75" stop-color="%s"/><stop offset="1" stop-color="%s"/></linearGradient>' % sky)
    o.append('<radialGradient id="gy"><stop offset="0" stop-color="#ffd988" stop-opacity=".75"/><stop offset="1" stop-color="#ffd988" stop-opacity="0"/></radialGradient>')
    o.append('<radialGradient id="go"><stop offset="0" stop-color="#ff8a2a" stop-opacity=".8"/><stop offset="1" stop-color="#ff8a2a" stop-opacity="0"/></radialGradient>')
    o.append('<radialGradient id="gc"><stop offset="0" stop-color="#8ff3ff" stop-opacity=".8"/><stop offset="1" stop-color="#8ff3ff" stop-opacity="0"/></radialGradient>')
    o.append('<radialGradient id="gv"><stop offset="0" stop-color="#c9a8ff" stop-opacity=".7"/><stop offset="1" stop-color="#c9a8ff" stop-opacity="0"/></radialGradient>')
    o.append('<radialGradient id="gs"><stop offset="0" stop-color="%s" stop-opacity="%s"/><stop offset="1" stop-color="%s" stop-opacity="0"/></radialGradient>' % (('#e9e6ff', '.55', '#e9e6ff') if N else ('#fff3b0', '.7', '#fff3b0')))
    o.append('<radialGradient id="vg" cx=".5" cy=".5" r=".75"><stop offset=".55" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#0a0720" stop-opacity="%s"/></radialGradient></defs>' % ('.55' if N else '.22'))
    # ---------- css ----------
    o.append('''<style>
.tw{animation:tw 3.2s steps(1) infinite}@keyframes tw{0%,55%{opacity:1}56%,100%{opacity:.15}}
.drift{animation:drift 110s linear infinite}@keyframes drift{from{transform:translateX(0)}to{transform:translateX(1800px)}}
.bob{animation:bob 2.6s steps(1) infinite}@keyframes bob{0%,49%{transform:translateY(0)}50%,100%{transform:translateY(-5px)}}
.flick{animation:flick .8s steps(1) infinite}@keyframes flick{0%{opacity:1}30%{opacity:.7}60%{opacity:.9}80%{opacity:.6}}
.glow{animation:glow 2.4s ease-in-out infinite}@keyframes glow{0%,100%{opacity:.55}50%{opacity:1}}
.smoke{animation:smoke 4s steps(8) infinite}@keyframes smoke{0%{opacity:0;transform:translate(0,0)}15%{opacity:.8}100%{opacity:0;transform:translate(15px,-60px)}}
.spark{animation:spark 1.6s steps(6) infinite}@keyframes spark{0%{opacity:0;transform:translate(0,0)}20%{opacity:1}100%{opacity:0;transform:translate(25px,-55px)}}
.rune{animation:rune 4s steps(8) infinite}@keyframes rune{0%{opacity:0;transform:translateY(0)}20%{opacity:1}100%{opacity:0;transform:translateY(-55px)}}
.float{animation:float 3s steps(1) infinite}@keyframes float{0%,49%{transform:translateY(0)}50%,100%{transform:translateY(-5px)}}
.sway{animation:sway 2.4s steps(1) infinite}@keyframes sway{0%,49%{transform:translateX(0)}50%,100%{transform:translateX(5px)}}
.flap{animation:flap 3s steps(1) infinite}@keyframes flap{0%,49%{transform:translateX(0)}50%,100%{transform:translateX(5px)}}
.fish{animation:fish 6s steps(1) infinite}@keyframes fish{0%,62%{opacity:0;transform:translate(0,0)}64%{opacity:1;transform:translate(-10px,-20px)}70%{transform:translate(-20px,-35px)}76%{transform:translate(-30px,-20px)}82%{transform:translate(-40px,0)}84%,100%{opacity:0;transform:translate(-40px,0)}}
.ripple{animation:ripple 2.4s steps(1) infinite}@keyframes ripple{0%,49%{opacity:.9}50%,100%{opacity:.35}}
.wander1{animation:w1 9s steps(1) infinite}@keyframes w1{0%{transform:translate(0,0)}20%{transform:translate(15px,-10px)}40%{transform:translate(30px,5px)}60%{transform:translate(10px,15px)}80%{transform:translate(-10px,5px)}}
.wander2{animation:w2 11s steps(1) infinite}@keyframes w2{0%{transform:translate(0,0)}25%{transform:translate(-20px,-10px)}50%{transform:translate(-5px,-25px)}75%{transform:translate(15px,-10px)}}
.wing{animation:wing .6s steps(1) infinite}@keyframes wing{0%{transform:scaleY(1)}50%{transform:scaleY(.4)}}
g,path,rect{transform-box:fill-box}
@media (prefers-reduced-motion:reduce){*{animation:none!important}}
</style>''')
    o.append('<g shape-rendering="crispEdges">')
    o.append('<rect width="%d" height="%d" fill="url(#sky)"/>' % (W, H))

    # ---------- небо ----------
    if N:
        st = {}
        for i in range(70):
            x = int(hsh(i, 1) * 255); y = int(hsh(i, 2) * 52)
            st[(x, y)] = '#ffffff' if hsh(i, 3) > 0.35 else '#cfd6ff'
        o.append(render({k: v for k, v in st.items() if hsh(k[0], k[1], 9) < 0.5}, 0, 0, P, th, ' class="tw"'))
        o.append(render({k: v for k, v in st.items() if hsh(k[0], k[1], 9) >= 0.5}, 0, 0, P, th, ' class="tw" style="animation-delay:-1.6s"'))
        mx, my = 1085, 105
        o.append('<circle cx="%d" cy="%d" r="95" fill="url(#gs)"/>' % (mx, my))
        moon = {}
        for yy in range(-6, 7):
            for xx in range(-6, 7):
                if xx * xx + yy * yy <= 33: moon[(xx, yy)] = '*#f1eeff'
        for (xx, yy) in [(-2, -2), (-1, -2), (2, 1), (3, 1), (-3, 2), (0, 3), (1, 3)]: moon[(xx, yy)] = '*#d5d0f2'
        o.append(render(moon, mx, my, P, th))
    else:
        sx, sy = 1085, 105
        o.append('<circle cx="%d" cy="%d" r="110" fill="url(#gs)"/>' % (sx, sy))
        sun = {}
        for yy in range(-6, 7):
            for xx in range(-6, 7):
                r2 = xx * xx + yy * yy
                if r2 <= 33: sun[(xx, yy)] = '*#ffe27a'
                if r2 <= 12: sun[(xx, yy)] = '*#fff3b0'
        o.append(render(sun, sx, sy, P, th))
        rays = {}
        for (xx, yy) in [(0, -9), (0, 9), (-9, 0), (9, 0), (7, 7), (-7, 7), (7, -7), (-7, -7)]:
            rays[(xx, yy)] = '*#ffe27a'
        o.append(render(rays, sx, sy, P, th, ' class="tw"'))
    # облака
    cl = ['....#####.......', '..#########.....', '.############...', '################', '.##############.']
    cl2 = ['...####....', '.########..', '###########', '.#########.']
    def cloud(rows, x, y, delay, op=1):
        d = parse(rows, {'#': '#ffffff'})
        for (cx_, cy_) in list(d):
            if cy_ == len(rows) - 1: d[(cx_, cy_)] = '#d9e8f6'
        c = '#ffffff'
        return '<g class="drift" style="animation-delay:%ds" opacity="%s">%s</g>' % (delay, op, render(d, x, y, P, th))
    if N:
        o.append(cloud(cl2, -220, 150, -20, '.22')); o.append(cloud(cl, -330, 70, -70, '.18'))
    else:
        o.append(cloud(cl, -80, 40, 0)); o.append(cloud(cl2, -400, 130, -30)); o.append(cloud(cl, -780, 70, -60, '.9')); o.append(cloud(cl2, -1000, 190, -85, '.8'))
    # ---------- горы ----------
    far = ridge(3, 62, 15)
    o.append(render(layer(far, G, '#a8bfe6', th, hi='#c0d2f0', snow=52), 0, 0, P, th))
    near = ridge(11, 70, 10)
    o.append(render(layer(near, G, '#86a4d4', th, hi='#a3bbe2', dither='#7b9ac9', snow=58, seed=4), 0, 0, P, th))
    # ---------- гирлянда вымпелов ----------
    pen = ['#46c6e6', '#5fd35f', '#f2d04a', '#4f7de8', '#f08a3a', '#a46be8']
    rope, flags_a, flags_b = {}, {}, {}
    for gx in range(0, 256):
        t = (gx * P - 640) / 660.0
        gy = int(round((2 + 7 * (1 - t * t))))
        rope[(gx, gy)] = '#5b3f22'
        if gx % 6 == 3:
            k = (gx // 6) % 6
            c = pen[k]; cl_ = mix(c, '#ffffff', 0.35)
            for i, w in enumerate([5, 5, 4, 3, 2, 1]):
                for xx in range(w):
                    tgt = flags_a if (gx // 6) % 2 == 0 else flags_b
                    tgt[(gx - w // 2 + xx, gy + 1 + i)] = cl_ if i == 0 else c
    o.append(render(rope, 0, 0, P, th)); o.append(render(flags_a, 0, 0, P, th, ' class="flap"')); o.append(render(flags_b, 0, 0, P, th, ' class="flap" style="animation-delay:-1.5s"'))
    # ---------- холмы, сосны, домики ----------
    mid = ridge(21, 76, 5)
    o.append(render(layer(mid, G, '#79bf68', th, hi='#9bd67f', dither='#68ad59', seed=5), 0, 0, P, th))
    # деревня на холме (над головами героев)
    for (gx, big) in [(14, False), (56, False), (118, True), (186, False), (226, False)]:
        hh = 9 if big else 7
        top = mid[min(255, gx + 7)]
        c = cottage(big)
        dy = top + 1 - (6 + hh)
        o.append(sprite_group(shift(c, gx, dy), 0, 0, th))
        wx = [(gx + 3, dy + 9), (gx + (14 if big else 10) - 1, dy + 9)]
        if N:
            for (wxx, wyy) in wx:
                o.append('<circle cx="%g" cy="%g" r="26" fill="url(#gy)" opacity=".55"/>' % ((wxx + 1) * P, (wyy + 1) * P))
        chx = gx + (13 if big else 9); chy = dy - 3
        o.append('<g class="smoke" style="animation-delay:%ds">%s</g>' % (-(gx % 4), render({(0, 0): '#e9e9ef', (1, 0): '#e9e9ef', (0, 1): '#e9e9ef', (1, 1): '#d6d6df'}, chx * P, chy * P, P, th)))
    for (gx, h) in [(3, 9), (34, 8), (44, 10), (80, 9), (92, 11), (101, 8), (150, 9), (160, 11), (168, 8), (206, 10), (214, 8), (246, 10), (252, 8), (74, 7)]:
        top = mid[min(255, gx + 3)]
        o.append(sprite_group(shift(pine(h), gx, top - h + 3), 0, 0, th))
    nh = ridge(33, 94, 5)
    o.append(render(layer(nh, G + 1, '#5fa84f', th, hi='#7bbf5f', dither='#559a46', seed=8), 0, 0, P, th))
    # ---------- земля ----------
    ground = {}
    for x in range(256):
        ground[(x, G)] = '#7bd05a'
        ground[(x, G + 1)] = '#5aa63f'
        for y in range(G + 2, 108):
            c = '#8b5e3c'
            r = hsh(x, y, 3)
            if r < 0.10: c = '#7a4f31'
            elif r < 0.17: c = '#9b6c47'
            elif r < 0.19: c = '#a8a8a8'
            ground[(x, y)] = c
        if hsh(x, 1, 2) < 0.25: ground[(x, G - 1)] = '#5aa63f'
        if hsh(x, 2, 5) < 0.06: ground[(x, G - 1)] = ['#e84a4a', '#ffd24a', '#ffffff', '#ff8ac8', '#6aa8ff'][int(hsh(x, 9) * 5)]
    o.append(render(ground, 0, 0, P, th))

    # ---------- пруд (срез грунта) ----------
    px0 = OX[0] + 22 * P
    pw = 14
    pond = {}
    for y in range(0, 7):
        for x in range(pw):
            c = '#58b2ee' if y == 0 else ('#3f9fe0' if y < 3 else ('#2f84c7' if y < 5 else '#2569ab'))
            pond[(x, y)] = c
    for x in range(pw): pond[(x, 7)] = '#6e4a2c'
    for (x, y) in [(0, 6), (pw - 1, 6)]: pond[(x, y)] = '#7a5a3a'
    o.append(render(pond, px0, G * P, P, th))
    ripples = {(3, 0): '#d7f1ff', (4, 0): '#d7f1ff', (9, 0): '#d7f1ff', (10, 0): '#d7f1ff', (6, 2): '#8ccaf5', (7, 2): '#8ccaf5', (11, 3): '#8ccaf5'}
    o.append(render(ripples, px0, G * P, P, th, ' class="ripple"'))
    o.append(render({(0, 0): '#4f9d3c', (1, 0): '#4f9d3c', (1, 1): '#4f9d3c', (0, 1): '#3a7f2d'}, px0 + 9 * P, G * P + P, P, th))
    for rx in (0, 13):
        o.append(render({(0, i): '#4f9d3c' for i in range(0, 4)}, px0 + rx * P, (G - 4) * P, P, th))
    bx = OX[0] + 25 * P + 2
    by_ = OY + 12 * P
    o.append('<rect x="%g" y="%g" width="2" height="%g" fill="%s" opacity=".75"/>' % (bx - 1, by_ + 5, GY - by_ - 5 + 2, th.c('#f4f8ff')))
    o.append(render({(0, 0): '#e84a4a', (1, 0): '#e84a4a', (0, 1): '#ffffff', (1, 1): '#ffffff'}, bx - 5, GY - 2, P // 2 + 0.5 if False else 5, th, ' class="float"'))
    fish = outlined({(0, 0): '#f2a65a', (1, 0): '#f2a65a', (2, 0): '#f2a65a', (3, 0): '#e8793a', (1, 1): '#fff2d8'}, '#2a1b17')
    o.append('<g class="fish">%s</g>' % render(fish, px0 + 9 * P, G * P - 8, P, th))

    # ---------- станции ----------
    builders = [build_fisher, build_farmer, build_lumber, build_miner, build_smith, build_enchanter]
    names = ['РЫБАК', 'ФЕРМЕР', 'ДРОВОСЕК', 'ШАХТЁР', 'КУЗНЕЦ', 'ЗАЧАРОВАТЕЛЬ']
    glows = {}
    for i, b in enumerate(builders):
        ox, cx = OX[i], CX[i]
        legs, up = b()
        # тень
        o.append('<rect x="%d" y="%d" width="%d" height="%d" fill="#000" opacity=".28"/>' % (cx - 40, GY, 80, 5))
        # предметы
        def prop(d, gx, ex='', outline=True):
            d = on_ground(d)
            return render(outlined(d) if outline else d, ox + gx * P, 0, P, th, ex)
        if i == 0:   # рыбак
            o.append(prop(crate_barrel(), -12))
        if i == 1:   # фермер
            o.append(prop(wheat(), -11, ' class="sway"')); o.append(prop(pumpkin_hay(), 21))
        if i == 2:   # дровосек
            o.append(prop(tree(), -8)); o.append(prop(logpile(), 21))
        if i == 3:   # шахтёр
            o.append(prop(minecart(), -11))
            o.append(prop(orebox(), 21))
            o.append('<circle cx="%d" cy="%d" r="40" fill="url(#gy)" class="glow"/>' % (ox + 21 * P + 2, (G - 8) * P))
            o.append(render(shift(torch_flame(), 0, G - 8), ox + 21 * P, 0, P, th, ' class="flick"'))
        if i == 4:   # кузнец
            fg = forge(); fy = (G - 1) - max(k[1] for k in fg)
            o.append(render(outlined(shift(fg, 0, fy)), ox - 9 * P, 0, P, th))
            o.append('<circle cx="%d" cy="%d" r="58" fill="url(#go)" class="glow"/>' % (ox - 9 * P + 5 * P, (G - 4) * P))
            o.append(render(shift(forge_fire(), 0, fy), ox - 9 * P, 0, P, th, ' class="flick"'))
            for sx_, dl in [(4, 0), (6, -.55), (3, -1.1)]:
                o.append('<g class="spark" style="animation-delay:%gs">%s</g>' % (dl, render({(0, 0): '*#ffd24a'}, ox - 9 * P + sx_ * P, (G - 7) * P, 4, th)))
            o.append(prop(anvil(), 21))
        if i == 5:   # зачарователь
            o.append(prop(bookshelf(), -8)); tb = on_ground(ench_table())
            tx = ox + 21 * P
            o.append(render(outlined(tb), tx, 0, P, th))
            o.append('<circle cx="%d" cy="%d" r="62" fill="url(#gv)" class="glow"/>' % (tx + 6 * P, (G - 10) * P))
            o.append('<g class="float">%s</g>' % render(outlined(shift(book(), 0, G - 13)), tx, 0, P, th))
            for k, (rx, col, dl) in enumerate([(-1, '*#c9a8ff', 0), (9, '*#8ff3ff', -1.3), (4, '*#c9a8ff', -2.6)]):
                o.append('<g class="rune" style="animation-delay:%gs">%s</g>' % (dl, render(rune(k, col), tx + rx * P, (G - 16) * P, 4, th)))
        # персонаж
        o.append(render(outlined(legs) if legs else {}, ox, OY, P, th) if legs else '')
        o.append(render(outlined(up), ox, OY, P, th, ' class="bob" style="animation-delay:%gs"' % (-0.35 * i)))
        # свечение лампы / посоха
        if i == 3: o.append('<circle cx="%d" cy="%d" r="34" fill="url(#gy)" class="glow"/>' % (ox + 10 * P, OY + 7 * P))
        if i == 5: o.append('<circle cx="%d" cy="%d" r="38" fill="url(#gc)" class="glow"/>' % (ox + 16 * P + 2, OY + 6 * P + 2))
        # табличка
        tw_ = text_width_px(names[i], 2) + 16
        plx = cx - tw_ // 2; ply = GY + 9
        plank = {}
        rect(plank, 0, 0, tw_ // 2 - 1, 4, '#8a5a2b')
        pl = '<rect x="%g" y="%g" width="%g" height="%g" fill="%s"/>' % (plx, ply, tw_, 25, th.c('#2a1b17'))
        pl += '<rect x="%g" y="%g" width="%g" height="%g" fill="%s"/>' % (plx + 2, ply + 2, tw_ - 4, 21, th.c('#9a6535'))
        pl += '<rect x="%g" y="%g" width="%g" height="%g" fill="%s"/>' % (plx + 2, ply + 2, tw_ - 4, 3, th.c('#b27a3d'))
        pl += '<rect x="%g" y="%g" width="%g" height="%g" fill="%s"/>' % (plx + 2, ply + 20, tw_ - 4, 3, th.c('#7a4a26'))
        o.append(pl)
        o.append(plain_text(names[i], plx + 8, ply + 6, 2, '*#fff1cf', th, shadow='*#3b2417'))

    # ---------- светлячки / бабочки ----------
    for k in range(9):
        x = int(80 + hsh(k, 1) * 1120); y = int(300 + hsh(k, 2) * 170)
        if N:
            o.append('<g class="wander%d" style="animation-delay:%gs"><circle cx="%d" cy="%d" r="9" fill="url(#gy)"/>%s</g>' % (1 + k % 2, -k * 1.3, x, y, render({(0, 0): '*#fff6a8'}, x - 2, y - 2, 4, th)))
        elif k < 5:
            c = ['#ff8ac8', '#ffd24a', '#ffffff', '#6aa8ff', '#ff8a4a'][k]
            o.append('<g class="wander%d" style="animation-delay:%gs"><g class="wing">%s</g></g>' % (1 + k % 2, -k * 1.7, render({(0, 0): c, (1, 0): c, (3, 0): c, (4, 0): c, (2, 0): '#3b2417'}, x, y, 3, th)))

    # ---------- заголовок ----------
    if N:
        ft, fb, ol, sh = '*#fff0c4', '*#ffc65a', '*#2a1530', '*#0a0618'
    else:
        ft, fb, ol, sh = '*#fff6d0', '*#ffc94a', '*#4a2a16', '*#2a1608'
    cells1, w1 = text_cells('RASKOL'); cells2, w2 = text_cells('PROFESSIONS')
    s1, s2 = 10, 5
    x1 = (W - w1 * s1) // 2 // 5 * 5; x2 = (W - w2 * s2) // 2 // 5 * 5
    if N: o.append('<ellipse cx="640" cy="130" rx="330" ry="90" fill="url(#gy)" opacity=".18"/>')
    o.append(logo_text('RASKOL', x1, 82, s1, ft, fb, ol, sh, th, split=3))
    o.append(logo_text('PROFESSIONS', x2, 166, s2, '*#fffdf2', '*#f1dfae', ol, sh, th, split=3))
    # плашка слогана
    tag = 'РЕМЕСЛА · УРОВНИ · ДВОЙНАЯ ДОБЫЧА'
    tw = text_width_px(tag, 3); pw_ = (tw + 64) // 10 * 10; pxl = (W - pw_) // 2 // 5 * 5; pyl = 214
    pl = '<rect x="%g" y="%g" width="%g" height="34" fill="%s"/>' % (pxl, pyl, pw_, th.c('#2a1b17'))
    pl += '<rect x="%g" y="%g" width="%g" height="28" fill="%s"/>' % (pxl + 3, pyl + 3, pw_ - 6, th.c('#7a4a26'))
    pl += '<rect x="%g" y="%g" width="%g" height="4" fill="%s"/>' % (pxl + 3, pyl + 3, pw_ - 6, th.c('#9a6535'))
    pl += '<rect x="%g" y="%g" width="%g" height="4" fill="%s"/>' % (pxl + 3, pyl + 27, pw_ - 6, th.c('#5b3519'))
    for (nx, ny) in [(pxl + 8, pyl + 8), (pxl + pw_ - 13, pyl + 8), (pxl + 8, pyl + 22), (pxl + pw_ - 13, pyl + 22)]:
        pl += '<rect x="%g" y="%g" width="4" height="4" fill="%s"/>' % (nx, ny, th.c('#d9b06a'))
    o.append(pl)
    o.append(plain_text(tag, (W - tw) // 2, pyl + 7, 3, '*#ffe9b0', th, shadow='*#2a1608'))
    o.append('</g>')
    o.append('<rect width="%d" height="%d" fill="url(#vg)"/>' % (W, H))
    title = 'RaskolProfessions — профессии, уровни и шанс удвоения добычи'
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" width="%d" height="%d" role="img" aria-labelledby="t d">'
            '<title id="t">%s</title><desc id="d">Уютная пиксельная деревня: рыбак, фермер, дровосек, шахтёр, кузнец и зачарователь у костров и лавок под гирляндой флажков.</desc>' % (W, H, W, H, title)
            + ''.join(o) + '</svg>')

if __name__ == '__main__':
    out = sys.argv[1] if len(sys.argv) > 1 else '.'
    for name, fn in (('day', 'banner.svg'), ('night', 'banner-dark.svg')):
        s = build(name)
        open('%s/%s' % (out, fn), 'w', encoding='utf-8').write(s)
        print(fn, len(s) // 1024, 'KB')
