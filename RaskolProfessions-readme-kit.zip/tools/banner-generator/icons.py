import sys
from engine import *

OUT = sys.argv[1] if len(sys.argv) > 1 else '.'
S = 6  # пиксель иконки

def save(name, d, w, h, glow=None, anim=''):
    th = Theme('day')
    body = render(outlined(d), 4, 4, S, th)
    svg = ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" width="%d" height="%d" shape-rendering="crispEdges" role="img" aria-label="%s">%s%s</svg>'
           % ((w + 2) * S + 2, (h + 2) * S + 2, (w + 2) * S + 2, (h + 2) * S + 2, name, (glow or ''), body))
    open('%s/%s.svg' % (OUT, name), 'w', encoding='utf-8').write(svg)

L = {'.': None}
def spr(rows, leg):
    return {(x, y): leg[ch] for y, r in enumerate(rows) for x, ch in enumerate(r) if ch not in '. '}

# 12×12
FISH = ['............',
        '...bbbb.....',
        '..bbbbbb..o.',
        '.bbwbbbbb.oo',
        '.bbbbbbbbbo.',
        '.bbbbbbbbbo.',
        '..bsssbbb.oo',
        '...bbbb...o.',
        '............']
fish = spr(FISH, {'b': '#46c6e6', 'w': '#ffffff', 's': '#bfeaf5', 'o': '#2f9bb7'})
fish[(3, 3)] = '#2b1d1a'

WHEAT = ['.....y......',
         '....yyy.....',
         '..y..y..y...',
         '.yyy.y.yyy..',
         '..y..y..y...',
         '.yyy.y.yyy..',
         '..y.hhh.y...',
         '....hhh.....',
         '.....s......',
         '.....s......']
wheat = spr(WHEAT, {'y': '#e6c84a', 'h': '#c76a12', 's': '#b8a23a'})

AXE = ['.......ggg..',
       '......gggg..',
       '.....ggggg..',
       '....wggggg..',
       '...ww.ggg...',
       '..ww........',
       '.ww.........',
       'ww..........']
axe = spr(AXE, {'g': '#9aa3ad', 'w': '#8a5a2b'})
for (x, y) in [(7, 0), (8, 0), (9, 0), (10, 1), (10, 2), (10, 3)]: axe[(x, y)] = '#d3dae1'
for (x, y) in [(3, 5), (5, 3), (4, 4)]: axe[(x, y)] = '#8a5a2b'

PICK = ['..gggggg....',
        '.gg.hhgg....',
        'g...hh..g...',
        '....hh......',
        '....hh......',
        '....hh......',
        '....hh......',
        '....hh......']
pick = spr(PICK, {'g': '#9aa3ad', 'h': '#8a5a2b'})
for x in range(2, 8): pick[(x, 0)] = '#d3dae1'
pick[(0, 2)] = '#6b727c'; pick[(8, 2)] = '#6b727c'

ANVIL = ['.ddddddddd..',
         'dddddddddddd',
         '..dddddd.dd.',
         '...dddd.....',
         '...dddd.....',
         '..dddddd....',
         '.dddddddd...']
anvil = spr(ANVIL, {'d': '#4a4d55'})
for x in range(1, 10): anvil[(x, 0)] = '#7a7f8a'
anvil[(2, 1)] = anvil[(3, 1)] = '#6a6e78'

BOOK = ['.vvvvvvvv...',
        'vppppppppv..',
        'vpcpppppppv.',
        'vppppcpppv..',
        'vpppppppppv.',
        'vpppcpppv...',
        '.vvvvvvvv...']
book = spr(BOOK, {'v': '#3d2570', 'p': '#8a5fd6', 'c': '#8ff3ff'})
book[(1, 1)] = '#a98cf0'
STAR = {(10, 0): '#fff3b0', (10, 1): '#fff3b0', (9, 1): '#fff3b0', (11, 1): '#fff3b0', (10, 2): '#fff3b0'}
book.update(STAR)

for n, d in [('fishing', fish), ('farming', wheat), ('lumber', axe), ('mining', pick), ('smithing', anvil), ('enchanting', book)]:
    save(n, d, 12, 10)

# --- разделитель: тропинка с цветами и ромбом посередине (одинаково хорош на светлой и тёмной теме) ---
def divider():
    th = Theme('day')
    d = {}
    W_ = 120
    for x in range(W_):
        d[(x, 3)] = '#6cc24a' if hsh(x, 1) > 0.2 else '#58a63f'
        d[(x, 4)] = '#5aa63f'
        d[(x, 5)] = '#8b5e3c' if hsh(x, 2) > 0.2 else '#7a4f31'
        d[(x, 6)] = '#7a4f31'
        if hsh(x, 3) < 0.10: d[(x, 2)] = '#5aa63f'
        if hsh(x, 4) < 0.07: d[(x, 2)] = ['#e84a4a', '#ffd24a', '#ffffff', '#ff8ac8', '#6aa8ff'][int(hsh(x, 5) * 5)]
    # ромб-самоцвет по центру
    cx = W_ // 2
    gem = {(0, -3): '#c8fff9', (-1, -2): '#8ff3ff', (0, -2): '#8ff3ff', (1, -2): '#4fe3d6', (-2, -1): '#8ff3ff', (-1, -1): '#4fe3d6', (0, -1): '#4fe3d6', (1, -1): '#2fb8b0', (2, -1): '#2fb8b0',
           (-1, 0): '#2fb8b0', (0, 0): '#2fb8b0', (1, 0): '#1f8f8a'}
    for (x, y), c in gem.items(): d[(cx + x, 1 + y + 3)] = c
    body = render(d, 0, 0, 4, th)
    fade = ('<defs><linearGradient id="f" x1="0" x2="1"><stop offset="0" stop-color="#fff" stop-opacity="0"/><stop offset=".18" stop-color="#fff"/>'
            '<stop offset=".82" stop-color="#fff"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient><mask id="m"><rect width="480" height="40" fill="url(#f)"/></mask></defs>')
    svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 480 32" width="480" height="32" shape-rendering="crispEdges" role="img" aria-label="">%s<g mask="url(#m)">%s</g></svg>' % (fade, body)
    open('%s/divider.svg' % OUT, 'w', encoding='utf-8').write(svg)
divider()
print('icons ok')
