"""Мини-движок пиксель-арта → SVG (спрайты, шрифт, ночной тинт, группировка в path)."""
import math

P = 5  # размер «майнкрафтовского» пикселя в единицах SVG

# ---------- цвет ----------
def hex2rgb(h):
    h = h.lstrip('#'); return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))

def rgb2hex(c):
    return '#%02x%02x%02x' % tuple(max(0, min(255, int(round(v)))) for v in c)

def mix(a, b, t):
    a, b = hex2rgb(a), hex2rgb(b)
    return rgb2hex(tuple(a[i] + (b[i] - a[i]) * t for i in range(3)))

def night(c):
    """Ночной тинт: к индиго + чуть темнее."""
    r = hex2rgb(mix(c, '#232a6a', 0.42))
    return rgb2hex(tuple(v * 0.93 for v in r))

class Theme:
    def __init__(self, name): self.name = name; self.night = (name == 'night')
    def c(self, col):
        if col.startswith('*'):          # эмиссивные цвета (окна, лампы, огонь) не тонируются
            return col[1:]
        return night(col) if self.night else col

# ---------- спрайты ----------
def parse(rows, legend, ox=0, oy=0):
    d = {}
    for y, row in enumerate(rows):
        for x, ch in enumerate(row):
            if ch not in '. ':
                d[(ox + x, oy + y)] = legend[ch]
    return d

def rect(d, x0, y0, x1, y1, c):
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            d[(x, y)] = c
    return d

def merge(*ds):
    o = {}
    for d in ds: o.update(d)
    return o

def shift(d, dx, dy):
    return {(x + dx, y + dy): c for (x, y), c in d.items()}

def outlined(d, col='#2a1b17'):
    """Тёмная обводка в 1 пиксель вокруг спрайта — единый стиль для всех персонажей и предметов."""
    o = {}
    for (x, y) in d:
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            k = (x + dx, y + dy)
            if k not in d: o[k] = col
    return merge(o, d)

def size(d):
    xs = [k[0] for k in d]; ys = [k[1] for k in d]
    return min(xs), min(ys), max(xs), max(ys)

def render(d, px=0, py=0, s=P, th=None, extra=''):
    """dict клеток → <g> с path-ами по цветам (горизонтальные серии склеены)."""
    by = {}
    for (x, y), c in d.items():
        by.setdefault(c, {}).setdefault(y, []).append(x)
    out = []
    for c, rows in by.items():
        segs = []
        for y, xs in sorted(rows.items()):
            xs.sort(); i = 0
            while i < len(xs):
                j = i
                while j + 1 < len(xs) and xs[j + 1] == xs[j] + 1: j += 1
                segs.append('M%g %gh%gv%gh-%gz' % (px + xs[i] * s, py + y * s, (j - i + 1) * s, s, (j - i + 1) * s))
                i = j + 1
        out.append('<path fill="%s" d="%s"/>' % (th.c(c) if th else c, ''.join(segs)))
    return '<g%s>%s</g>' % (extra, ''.join(out))

# ---------- пиксельный шрифт 5×7 (латиница + кириллица) ----------
F = {}
def _g(ch, *rows): F[ch] = rows
_g('A', '.###.', '#...#', '#...#', '#####', '#...#', '#...#', '#...#')
_g('R', '####.', '#...#', '#...#', '####.', '#.#..', '#..#.', '#...#')
_g('S', '.####', '#....', '#....', '.###.', '....#', '....#', '####.')
_g('K', '#...#', '#..#.', '#.#..', '##...', '#.#..', '#..#.', '#...#')
_g('O', '.###.', '#...#', '#...#', '#...#', '#...#', '#...#', '.###.')
_g('L', '#....', '#....', '#....', '#....', '#....', '#....', '#####')
_g('P', '####.', '#...#', '#...#', '####.', '#....', '#....', '#....')
_g('F', '#####', '#....', '#....', '####.', '#....', '#....', '#....')
_g('E', '#####', '#....', '#....', '####.', '#....', '#....', '#####')
_g('I', '.###.', '..#..', '..#..', '..#..', '..#..', '..#..', '.###.')
_g('N', '#...#', '##..#', '##..#', '#.#.#', '#..##', '#..##', '#...#')
# кириллица
_g('А', *F['A']); _g('Р', *F['P']); _g('О', *F['O']); _g('Е', *F['E']); _g('К', *F['K'])
_g('Ш', '#.#.#', '#.#.#', '#.#.#', '#.#.#', '#.#.#', '#.#.#', '#####')
_g('Х', '#...#', '#...#', '.#.#.', '..#..', '.#.#.', '#...#', '#...#')
_g('Т', '#####', '..#..', '..#..', '..#..', '..#..', '..#..', '..#..')
_g('Ё', '.#.#.', '#####', '#....', '####.', '#....', '#....', '#####')
_g('Ф', '..#..', '.###.', '#.#.#', '#.#.#', '#.#.#', '.###.', '..#..')
_g('М', '#...#', '##.##', '#.#.#', '#.#.#', '#...#', '#...#', '#...#')
_g('С', '.####', '#....', '#....', '#....', '#....', '#....', '.####')
_g('Л', '..###', '.#..#', '.#..#', '.#..#', '.#..#', '.#..#', '#...#')
_g('У', '#...#', '#...#', '#...#', '.####', '....#', '...#.', '###..')
_g('В', '####.', '#...#', '#...#', '####.', '#...#', '#...#', '####.')
_g('Н', '#...#', '#...#', '#...#', '#####', '#...#', '#...#', '#...#')
_g('И', '#...#', '#..##', '#..##', '#.#.#', '##..#', '##..#', '#...#')
_g('Й', '.###.', '#..##', '#..##', '#.#.#', '##..#', '##..#', '#...#')
_g('Д', '.####', '.#..#', '.#..#', '.#..#', '.#..#', '#####', '#...#')
_g('Я', '.####', '#...#', '#...#', '.####', '..#.#', '.#..#', '#...#')
_g('Б', '#####', '#....', '####.', '#...#', '#...#', '#...#', '####.')
_g('Ы', '#....#', '#....#', '#....#', '###..#', '#..#.#', '#..#.#', '###..#')
_g('Ч', '#...#', '#...#', '#...#', '.####', '....#', '....#', '....#')
_g('Ц', '#..#.', '#..#.', '#..#.', '#..#.', '#..#.', '#####', '....#')
_g('З', '####.', '....#', '....#', '.###.', '....#', '....#', '####.')
_g('Ь', '#....', '#....', '#....', '####.', '#...#', '#...#', '####.')
_g('П', '#####', '#...#', '#...#', '#...#', '#...#', '#...#', '#...#')
_g('Ю', '#..#.', '#.#.#', '#.#.#', '###.#', '#.#.#', '#.#.#', '#..#.')
_g('·', '.....', '.....', '.....', '..#..', '.....', '.....', '.....')
_g(',', '.....', '.....', '.....', '.....', '..#..', '..#..', '.#...')
_g(' ', '...', '...', '...', '...', '...', '...', '...')
_g('◆', '.....', '..#..', '.###.', '#####', '.###.', '..#..', '.....')

def text_cells(txt, gap=1):
    """→ dict {(x,y): индекс_строки}, ширина в клетках."""
    d = {}; x = 0
    for ch in txt:
        g = F[ch]
        for y, row in enumerate(g):
            for i, v in enumerate(row):
                if v == '#': d[(x + i, y)] = y
        x += len(g[0]) + gap
    return d, x - gap

def text_width_px(txt, s, gap=1):
    return text_cells(txt, gap)[1] * s

def logo_text(txt, px, py, s, face_top, face_bot, outline, shadow, th, gap=1, split=3):
    """Майнкрафтовский логотип: тень + обводка + двухтонная заливка."""
    cells, _ = text_cells(txt, gap)
    h = s // 2
    sh = {k: shadow for k in cells}
    ol = {k: outline for k in cells}
    face = {k: (face_top if r < split else face_bot) for k, r in cells.items()}
    parts = [render(sh, px + h, py + s, s, th, ' opacity=".38"')]
    for dx in (-h, 0, h):
        for dy in (-h, 0, h):
            if dx or dy: parts.append(render(ol, px + dx, py + dy, s, th))
    parts.append(render(face, px, py, s, th))
    return ''.join(parts)

def plain_text(txt, px, py, s, col, th, gap=1, shadow=None):
    cells, _ = text_cells(txt, gap)
    o = ''
    if shadow: o += render({k: shadow for k in cells}, px + max(1, s // 3), py + max(1, s // 3), s, th)
    return o + render({k: col for k in cells}, px, py, s, th)

# ---------- детерминированный «шум» ----------
def hsh(a, b=0, seed=7):
    n = (a * 374761393 + b * 668265263 + seed * 1442695041) & 0xFFFFFFFF
    n = (n ^ (n >> 13)) * 1274126177 & 0xFFFFFFFF
    return ((n ^ (n >> 16)) & 0xFFFF) / 65535.0
